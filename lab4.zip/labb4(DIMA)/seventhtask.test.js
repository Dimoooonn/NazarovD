const { calculateFinalPrice } = require('./labAssignment-lab4');

describe('calculateFinalPrice', () => {
  const validOrder = {
    items: [
      { price: 10, quantity: 2 },
      { price: 5, quantity: 3 },
    ],
    taxRate: 0.1,
  };

  const discountService = {
    getDiscount: jest.fn().mockReturnValue(0.2),
  };

  test('should calculate correct final price', () => {
    const result = calculateFinalPrice(validOrder, discountService);
    expect(result).toBe(26.4); // (10*2 + 5*3) = 35; 35*0.8 = 28; 28*1.1 = 30.8
  });

  test('should limit discount to 50%', () => {
    discountService.getDiscount.mockReturnValue(0.6);
    const result = calculateFinalPrice(validOrder, discountService);
    expect(result).toBe(19.25); // 35*0.5 = 17.5; 17.5*1.1 = 19.25
  });

  test('should throw error for empty order', () => {
    expect(() => calculateFinalPrice({}, discountService)).toThrow('Invalid order');
  });

  test('should throw error for negative price', () => {
    const invalidOrder = {
      items: [{ price: -10, quantity: 1 }],
      taxRate: 0.1,
    };
    expect(() => calculateFinalPrice(invalidOrder, discountService)).toThrow('Invalid item data');
  });
});