const { ApiClient } = require('./labAssignment-lab4');

global.fetch = jest.fn(() =>
  Promise.resolve({
    json: () => Promise.resolve({ data: 'test' }),
  })
);

describe('ApiClient', () => {
  test('fetchData should return data with fetchedAt', async () => {
    const apiClient = new ApiClient();
    const result = await apiClient.fetchData();
    
    expect(result).toHaveProperty('data', 'test');
    expect(result).toHaveProperty('fetchedAt');
    expect(typeof result.fetchedAt).toBe('number');
  });
});