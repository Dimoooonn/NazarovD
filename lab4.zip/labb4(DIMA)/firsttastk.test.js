const { UserService } = require('./labAssignment-lab4');

describe('UserService', () => {
  test('greet() should call getFullName with "John" and "Doe"', () => {
    const mockGetFullName = jest.fn().mockReturnValue('John Doe');
    const userService = new UserService(mockGetFullName);
    
    userService.greet();
    
    expect(mockGetFullName).toHaveBeenCalledWith('John', 'Doe');
  });

  test('greet() should return greeting in uppercase', () => {
    const mockGetFullName = jest.fn().mockReturnValue('John Doe');
    const userService = new UserService(mockGetFullName);
    
    const result = userService.greet();
    
    expect(result).toBe('HELLO, JOHN DOE!');
  });
});