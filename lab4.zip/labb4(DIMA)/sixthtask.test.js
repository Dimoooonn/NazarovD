const { ApiHelper } = require('./labAssignment-lab4');

describe('ApiHelper', () => {
  test('fetchViaHelper should return data from apiCallFunction', async () => {
    const mockApiCall = jest.fn().mockResolvedValue({ key: 'value' });
    const apiHelper = new ApiHelper();
    
    const result = await apiHelper.fetchViaHelper(mockApiCall);
    
    expect(result).toEqual({ key: 'value' });
  });

  test('fetchViaHelper should throw error for invalid data', async () => {
    const mockApiCall = jest.fn().mockResolvedValue(null);
    const apiHelper = new ApiHelper();
    
    await expect(apiHelper.fetchViaHelper(mockApiCall)).rejects.toThrow('Invalid data');
  });
});