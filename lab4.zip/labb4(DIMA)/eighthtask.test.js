const { OrderProcessor } = require('./labAssignment-lab4');

describe('OrderProcessor', () => {
  const validOrder = {
    items: [{ price: 10, quantity: 2 }],
    taxRate: 0.1,
    currency: 'USD',
  };

  test('should convert currency when converter is available', async () => {
    const mockConverter = jest.fn().mockResolvedValue(25);
    const processor = new OrderProcessor(mockConverter);
    
    const result = await processor.processOrder(validOrder, 'EUR');
    
    expect(result).toBe(25);
    expect(mockConverter).toHaveBeenCalled();
  });

  test('should return original price when converter fails', async () => {
    const mockConverter = jest.fn().mockRejectedValue(new Error('Conversion failed'));
    const processor = new OrderProcessor(mockConverter);
    
    const result = await processor.processOrder(validOrder, 'EUR');
    
    expect(result).toBe(22); // 10*2 = 20; 20*1.1 = 22
  });

  test('should return original price when no target currency', async () => {
    const mockConverter = jest.fn();
    const processor = new OrderProcessor(mockConverter);
    
    const result = await processor.processOrder(validOrder);
    
    expect(result).toBe(22);
    expect(mockConverter).not.toHaveBeenCalled();
  });
});