const { computeValue, getNumber } = require('./labAssignment-lab4');

jest.mock('./labAssignment-lab4', () => {
  const originalModule = jest.requireActual('./labAssignment-lab4');
  return {
    ...originalModule,
    getNumber: jest.fn().mockResolvedValue(42),
  };
});

test('computeValue should return 94', async () => {
  const result = await computeValue();
  expect(result).toBe(94);
});