const { Builder, By, until } = require('selenium-webdriver');
const edge = require('selenium-webdriver/edge');

describe('Wikipedia Search Test', () => {
  let driver;

  beforeAll(async () => {
    driver = await new Builder()
      .forBrowser('MicrosoftEdge')
      .setEdgeOptions(new edge.Options().addArguments('--start-maximized'))
      .build();
  }, 15000); 

  afterAll(async () => {
    await driver.quit();
  });

  test('Search for Selenium', async () => {

    jest.setTimeout(20000);

    await driver.get('https://www.wikipedia.org');

    const searchInput = await driver.wait(
      until.elementLocated(By.id('searchInput')),
      10000
    );
    await searchInput.sendKeys('Selenium');

    
    const searchButtonSelectors = [
      By.css('button.pure-button'), 
      By.css('button[type="submit"]'),
      By.css('.search-container button'), 
      By.css('#search-form button') 
    ];

    let searchButton;
    for (const selector of searchButtonSelectors) {
      try {
        searchButton = await driver.wait(
          until.elementLocated(selector),
          2000
        );
        break;
      } catch (e) {
        continue;
      }
    }

    if (!searchButton) {
      throw new Error('Не вдалося знайти кнопку пошуку');
    }

    await searchButton.click();


    await driver.wait(until.titleContains('Selenium'), 10000);
    
 
    const heading = await driver.wait(
      until.elementLocated(By.id('firstHeading')),
      5000
    );
    expect(await heading.getText()).toMatch(/selenium/i);
  }, 20000); 
});