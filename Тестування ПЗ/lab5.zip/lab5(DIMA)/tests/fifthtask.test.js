const { Builder, By, until } = require('selenium-webdriver');
const edge = require('selenium-webdriver/edge');

describe('Wikipedia Selenium Chemical Properties Test', () => {
  let driver;

  beforeAll(async () => {
    driver = await new Builder()
      .forBrowser('MicrosoftEdge')
      .setEdgeOptions(new edge.Options())
      .build();
  });

  afterAll(async () => {
    if (driver) {
      await driver.quit();
    }
  });

  // Функція для нормалізації кольору
  const normalizeColor = (color) => {
    return color.toLowerCase()
      .replace(/\s+/g, '')
      .replace('rgba', 'rgb')
      .replace(/,[\d.]+\)$/, ')');
  };

  test('Verify Selenium chemical properties in infobox', async () => {
    jest.setTimeout(30000);

    try {
      // Відкриття сторінки
      await driver.get('https://en.wikipedia.org/wiki/Selenium');
      await driver.wait(until.titleContains('Selenium'), 10000);

      // Очікування елемента
      const chemicalElement = await driver.wait(
        until.elementLocated(By.xpath('//th[@class="navbox-group" and contains(text(), "Se(−II)")]')),
        15000
      );

      // Перевірка тексту
      expect(await chemicalElement.getText()).toBe('Se(−II)');
      
      // Отримання кольору фону
      const backgroundColor = await chemicalElement.getCssValue('background-color');
      console.log('Actual background color:', backgroundColor);
      
      // Очікувані кольори (тепер з правильним форматом)
      const expectedColors = [
        'rgb(221,221,255)',    // Основний варіант
        'rgba(221,221,255,1)', // Альтернатива з альфа-каналом
        'rgb(253,255,140)',    // Запасний варіант 1
        'rgb(128,240,120)'     // Запасний варіант 2
      ].map(normalizeColor);

      // Нормалізація фактичного кольору
      const normalizedActual = normalizeColor(backgroundColor);
      console.log('Normalized actual color:', normalizedActual);
      console.log('Expected colors:', expectedColors);

      // Перевірка
      expect(expectedColors).toContain(normalizedActual);

    } catch (error) {
      console.error('Test failed:', error);
      throw error;
    }
  });
});