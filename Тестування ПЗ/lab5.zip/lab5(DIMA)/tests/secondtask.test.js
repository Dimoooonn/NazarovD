const { Builder, By, until } = require('selenium-webdriver');

describe('Wikipedia Comprehensive Test', () => {
  let driver;

  beforeAll(async () => {
    driver = await new Builder().forBrowser('chrome').build();
    await driver.manage().window().maximize();
  });

  afterAll(async () => {
    await driver.quit();
  });

  test('Validate Wikipedia homepage elements', async () => {
    await driver.get('https://www.wikipedia.org');
    
    // Чекаємо, поки поле пошуку з'явиться
    const searchInput = await driver.wait(until.elementLocated(By.id('searchInput')), 5000);
    expect(await searchInput.isDisplayed()).toBeTruthy();
    
    // Перевіряємо альтернативні локатори
    expect(await driver.findElement(By.name('search')).isDisplayed()).toBeTruthy();
    
    // Перевіряємо логотип
    const logo = await driver.wait(until.elementLocated(By.css('.central-featured-logo')), 5000);
    expect(await logo.isDisplayed()).toBeTruthy();
  });
});