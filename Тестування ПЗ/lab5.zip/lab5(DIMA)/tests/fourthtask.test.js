const { Builder, By, until } = require('selenium-webdriver');
const edge = require('selenium-webdriver/edge');

describe('Wikipedia Element Access (Task 4)', () => {
  let driver;

  beforeAll(async () => {
    driver = await new Builder()
      .forBrowser('MicrosoftEdge')
      .setEdgeOptions(new edge.Options().addArguments('--start-maximized'))
      .build();
    await driver.manage().setTimeouts({ implicit: 10000 });
  }, 15000); 

  afterAll(async () => {
    if (driver) {
      await driver.quit();
    }
  });

  test('Check article page elements', async () => {
    jest.setTimeout(20000); 

    try {
  
      await driver.get('https://en.wikipedia.org/wiki/Selenium');
      
   
      await driver.wait(until.titleContains('Selenium'), 10000);

 
      const articleTitle = await driver.wait(
        until.elementLocated(By.id('firstHeading')),
        5000
      );
      const titleText = await articleTitle.getText();
      expect(titleText).toMatch(/^Selenium$/i);


      const navLinks = await driver.wait(
        until.elementsLocated(By.css('#p-navigation .vector-menu-content li a')),
        5000
      );
      expect(navLinks.length).toBeGreaterThan(0);


      const firstLink = await navLinks[0].getAttribute('href');
      expect(firstLink).toMatch(/^https:\/\/en\.wikipedia\.org\/wiki\/[A-Za-z0-9_]+$/);


      const content = await driver.wait(
        until.elementLocated(By.id('mw-content-text')),
        5000
      );
      expect(await content.isDisplayed()).toBeTruthy();

    } catch (error) {
      console.error('Test failed:', error);
      throw error;
    }
  });
});